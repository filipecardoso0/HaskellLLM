import Tests

main :: IO ()
main = do
  putStrLn "Running tests..."
  runAllTests
  putStrLn "Done."